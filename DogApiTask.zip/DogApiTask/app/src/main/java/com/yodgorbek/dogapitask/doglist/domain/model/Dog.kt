package com.yodgorbek.dogapitask.doglist.domain.model

data class Dog(
    val photoUrl: String,
)
