package com.yodgorbek.dogapitask.doglist.domain.model

data class Breed(val id: String, val name: String)
